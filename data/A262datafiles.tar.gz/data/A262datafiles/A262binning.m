clear all;
close all;

tic

load('A262_evts_07_7kev.txt');
%load('A262_bg_07_7kev.txt');  For the background file
data1=A262_evts_07_7kev;
%data1=A262_bg_07_7kev.txt;  For the background file
[m  n]=size(data1);
sky_x(1:m,1)=data1(1:m,11);
sky_y(1:m,1)=data1(1:m,12);
PI_chan(1:m,1)=data1(1:m,16);
PI_chan_min=min(PI_chan);
PI_chan_max=max(PI_chan);

x_point=4096.5;
y_point=4096.5;

dx=sky_x(1:m,1)-x_point;
dy=sky_y(1:m,1)-y_point;
nbins=1024;

cellsize=2.;   
xyrange=cellsize*(nbins -1.)/2.; 
npts=zeros(nbins,nbins);

xpos=zeros(nbins,nbins);
ypos=zeros(nbins,nbins);
PI_counts=zeros(PI_chan_max,nbins,nbins);

for ii=1:m
    u=dx(ii,1);
    v=dy(ii,1);
    vr=PI_chan(ii,1);
    ifail=0;
    signx=1.;
    if(u<0.0) 
        signx=-1;
    end
    signy=1.;
    if(v<0.0)
        signy=-1;
    end
    icentre=nbins/2 +1;
    jcentre=nbins/2 +1;
    i=floor(u/cellsize +signx*0.5) +icentre;
    j=floor(v/cellsize +signy*0.5) +jcentre;
    if(i<1 || i>nbins) 
        ifail=1;
    end
    if(j<1 || j>nbins) 
        ifail=1;
    end
    if(ifail==1)
      continue
    end
    
    npts(i,j)= npts(i,j)+1;
    xpos(i,j)=xpos(i,j)+u;
    ypos(i,j)=ypos(i,j)+v;
    PI_counts(vr,i,j)=PI_counts(vr,i,j)+1;
end

[e f g]=size(PI_counts);
w=0;


    for j=1:f
        for k=1:g
            for i=48:e
                w=w+1;
                count_obs(w,1)=PI_counts(i,j,k);
            end
  
        end
    end
    
    
    filename='A262data_256by256by433.txt';
    %filename='A262BG_256by256by433.txt';
    
  fid = fopen(filename, 'w');
   fprintf(fid,' %5d\n',count_obs);  
   
   
   
toc